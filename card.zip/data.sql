-- Drop existing tables if they exist
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS id_uploads;
DROP TABLE IF EXISTS audit_logs;
DROP TABLE IF EXISTS user_pins;
DROP TABLE IF EXISTS wallet_balances;
DROP TABLE IF EXISTS rewards;
DROP TABLE IF EXISTS affiliates;

-- Create Users Table
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    phone VARCHAR(20) UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,  -- Store hashed password
    profile_picture TEXT,         -- URL for profile picture (optional)
    role VARCHAR(50) DEFAULT 'user', -- User role (e.g., user, admin)
    user_type VARCHAR(50) DEFAULT 'basic', -- User type (e.g., basic, premium, etc.)
    is_verified BOOLEAN DEFAULT FALSE, -- Flag for email verification status
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP -- Track last login time
);

-- Create Wallet Balances Table
CREATE TABLE IF NOT EXISTS wallet_balances (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    balance DECIMAL(10, 2) DEFAULT 0.00,  -- User's wallet balance
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create Rewards Table
CREATE TABLE IF NOT EXISTS rewards (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    points INT DEFAULT 0,  -- Reward points
    level INT DEFAULT 1,   -- Reward level
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create Affiliates Table (Unilevel Structure)
CREATE TABLE IF NOT EXISTS affiliates (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,  -- The user who is the affiliate
    sponsor_id INTEGER,  -- The sponsor (upline)
    affiliate_level INT DEFAULT 1,  -- Affiliate level in the unilevel structure
    referral_code VARCHAR(50) UNIQUE,  -- Unique referral code
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create ID Uploads Table
CREATE TABLE IF NOT EXISTS id_uploads (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    file_url TEXT NOT NULL,         -- URL to the uploaded ID file
    file_type VARCHAR(50),         -- Type of ID (e.g., passport, driver license)
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(50) DEFAULT 'pending' -- Status of upload (pending, approved, rejected)
);

-- Create Audit Logs Table (to keep track of user actions)
CREATE TABLE IF NOT EXISTS audit_logs (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    action TEXT NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    details TEXT -- Extra details about the action
);

-- Create a table for storing PIN codes (if required for PIN validation)
CREATE TABLE IF NOT EXISTS user_pins (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    pin_hash TEXT NOT NULL, -- Store hashed PIN for security
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert a sample user into the users table
INSERT INTO users (first_name, last_name, email, phone, password_hash, role, user_type)
VALUES 
    ('John', 'Doe', 'john.doe@example.com', '1234567890', 'hashedpassword123', 'user', 'premium'),
    ('Jane', 'Smith', 'jane.smith@example.com', '0987654321', 'hashedpassword456', 'user', 'basic');

-- Sample data for ID uploads (linking to user_id)
INSERT INTO id_uploads (user_id, file_url, file_type)
VALUES 
    (1, 'https://storage.googleapis.com/path/to/johndoe-id.png', 'passport'),
    (2, 'https://storage.googleapis.com/path/to/janesmith-id.png', 'driver_license');

-- Insert sample rewards
INSERT INTO rewards (user_id, points, level)
VALUES 
    (1, 1000, 2),
    (2, 500, 1);

-- Sample data for Wallet Balances
INSERT INTO wallet_balances (user_id, balance)
VALUES 
    (1, 1500.00),
    (2, 300.50);

-- Sample data for Affiliates (Unilevel Structure)
INSERT INTO affiliates (user_id, sponsor_id, affiliate_level, referral_code)
VALUES 
    (1, NULL, 1, 'REF123'),
    (2, 1, 2, 'REF456');

-- Insert sample audit logs
INSERT INTO audit_logs (user_id, action, details)
VALUES 
    (1, 'Account created', 'User created their account with email john.doe@example.com'),
    (2, 'ID uploaded', 'User uploaded their driver license');

-- Insert sample PIN data (hashed PIN)
INSERT INTO user_pins (user_id, pin_hash)
VALUES 
    (1, 'hashedpin123'),
    (2, 'hashedpin456');